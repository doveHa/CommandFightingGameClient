﻿using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Text.Json;
using System.Threading.Tasks;
using DTO;
using Manager;
using RestAPI;
using RestSharp;
using UnityEngine;
using UnityEngine.InputSystem;

namespace Handler
{
    public class CommandRecodeHandler : MonoBehaviour
    {
        [SerializeField] private CharacterSelectHandler characterSelectHandler;
        public Dictionary<string, List<string>> ChangeCommandList { get; set; }
        private List<string> recode;
        private bool isRecode, isChanged;

        IEnumerator Start()
        {
            yield return new WaitUntil(() =>
                CharacterManager.Manager.CharacterGroup.CurrentCommandList != null);

            ChangeCommandList = DeepCopy(CharacterManager.Manager.CharacterGroup.CurrentCommandList);
            recode = new List<string>();
            isChanged = false;
        }


        public void StartRecode()
        {
            if (isRecode)
            {
                return;
            }

            isRecode = true;
            InputActionManager.Manager.Inputs.Command.CommandInput.started += CommandRecoding;
        }

        public void StopRecode()
        { 
            InputActionManager.Manager.Inputs.Command.CommandInput.started -= CommandRecoding;
            string key = CharacterSelectHandler.CurrentShowCharacter + "+" + CharacterSelectHandler.CurrentShowSkill;
            Debug.Log(ChangeCommandList.ContainsKey(key));
            ChangeCommandList[key] = recode.ToList();
            CharacterManager.Manager.CharacterGroup.ChangeCommand(CharacterSelectHandler.CurrentShowCharacter,
                CharacterSelectHandler.CurrentShowSkill, recode.ToList());
            characterSelectHandler.ChangeSkillSet();
            recode.Clear();
            isRecode = false;
        }


        public async Task SendCommand()
        {
            if (isChanged)
            {
                List<SetCommandDTO> sendCommands = CommandDictionaryToList(ChangeCommandList);

                var json = JsonSerializer.Serialize(sendCommands);
                Debug.Log(json);

                RestResponse response = await Request.Post(Constant.RestAPI.CustomCommand.SET, sendCommands,
                    LoginManager.Manager.GetAuthHeader());

                if (response.IsSuccessful)
                {
                    CharacterManager.Manager.CharacterGroup.CurrentCommandList = DeepCopy(ChangeCommandList);
                }

                isChanged = false;
            }
        }

        private void CommandRecoding(InputAction.CallbackContext context)
        {
            isChanged = true;
            recode.Add(context.control.name.ToUpper());
        }

        private List<SetCommandDTO> CommandDictionaryToList(Dictionary<string, List<string>> commandList)
        {
            List<SetCommandDTO> list = new List<SetCommandDTO>();
            foreach (KeyValuePair<string, List<string>> keyValuePair in commandList)
            {
                string[] keys = keyValuePair.Key.Split('+');
                list.Add(new SetCommandDTO(keys[0], keys[1], keyValuePair.Value));
            }

            return list;
        }

        private Dictionary<string, List<string>> DeepCopy(Dictionary<string, List<string>> original)
        {
            Dictionary<string, List<string>> copy = new Dictionary<string, List<string>>();
            foreach (KeyValuePair<string, List<string>> command in original)
            {
                copy.Add(command.Key, command.Value);
            }

            return copy;
        }
    }
}