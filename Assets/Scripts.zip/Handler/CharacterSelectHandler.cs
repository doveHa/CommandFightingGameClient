﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Characters;
using Manager;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace Handler
{
    public class CharacterSelectHandler : MonoBehaviour
    {
        [SerializeField] private GameObject description;
        [SerializeField] private Image[] images;
        [SerializeField] private GameObject[] buttons;

        public static string CurrentShowCharacter { get; private set; }
        public static string CurrentShowSkill { get; private set; }
        private Color defaultColor, selectCharacterColor;

        void Start()
        {
            defaultColor = images[0].color;
            ColorUtility.TryParseHtmlString("#4690F0", out selectCharacterColor);
        }

        public void AllDescriptionOff()
        {
            for (int i = 0; i < description.transform.childCount; i++)
            {
                images[i].color = defaultColor;
                description.transform.GetChild(i).gameObject.SetActive(false);
            }
        }

        public async void OnClickCharacterInfo(int index)
        {
            AllDescriptionOff();
            images[index].color = selectCharacterColor;
            switch (index)
            {
                case 0:
                    CurrentShowCharacter = "Naktis";
                    break;
                case 1:
                    CurrentShowCharacter = "Kagetsu";
                    break;
                case 2:
                    CurrentShowCharacter = "Vargon";
                    break;
            }

            await SkillButtonOn();
            ChangeSkillSet();
            description.transform.GetChild(index).gameObject.SetActive(true);
        }

        public async Task SkillButtonOn()
        {
            AllSkillDescriptionOff();
            CharacterManager.Manager.CharacterGroup.Characters.TryGetValue(CurrentShowCharacter, out var character);
            List<ISkill> skills = character.SkillGroup.Skills.Values.ToList();
            for (int i = 0; i < skills.Count; i++)
            {
                int index = i;
                buttons[index].GetComponent<Image>().sprite =
                    Resources.Load<Sprite>("Images/Icon/SkillIcon/" + skills[index].Name);
                buttons[index].SetActive(true);
                buttons[index].GetComponent<Button>().onClick
                    .AddListener(() => OnClickSkillIcon(skills[index].Name, buttons, index));
            }
        }

        public void ChangeSkillSet()
        {
            CharacterManager.Manager.CharacterGroup.Characters.TryGetValue(CurrentShowCharacter, out var character);
            List<ISkill> skillList = character.SkillGroup.Skills.Values.ToList();

            for (int i = 0; i < skillList.Count; i++)
            {
                SkillInfoChange(skillList[i],buttons[i].transform.GetChild(0).gameObject);
            }
        }
        

        public void AllSkillInfoOff()
        {
            foreach (GameObject button in buttons)
            {
                button.transform.GetChild(0).gameObject.SetActive(false);
                button.gameObject.SetActive(false);
            }
        }

        private void SkillInfoChange(ISkill skill, GameObject SkillInfo)
        {
            TextMeshProUGUI name = SkillInfo.transform.Find("Title").GetComponent<TextMeshProUGUI>();
            TextMeshProUGUI description =
                SkillInfo.transform.Find("Description").GetComponent<TextMeshProUGUI>();
            name.text = skill.Name;
            description.text = skill.Description;

            TextMeshProUGUI commandText = SkillInfo.transform.Find("Command").transform.Find("CommandText")
                .transform
                .Find("Key").GetComponent<TextMeshProUGUI>();
            commandText.text = CommandListToString(skill.Command);
        }

        private static string CommandListToString(List<string> commands)
        {
            string sumCommand = "";
            foreach (string command in commands)
            {
                switch (command)
                {
                    case "UPARROW":
                        sumCommand += "↑ ";
                        break;
                    case "DOWNARROW":
                        sumCommand += "↓ ";
                        break;
                    case "LEFTARROW":
                        sumCommand += "← ";
                        break;
                    case "RIGHTARROW":
                        sumCommand += "→ ";
                        break;
                    default:
                        sumCommand += command + " ";
                        break;
                }
            }

            return sumCommand;
        }

        private void OnClickSkillIcon(string skillName, GameObject[] buttons, int index)
        {
            CurrentShowSkill = skillName;
            AllSkillDescriptionOff();
            buttons[index].transform.GetChild(0).gameObject.SetActive(true);
        }

        private void AllSkillDescriptionOff()
        {
            foreach (GameObject button in buttons)
            {
                button.transform.GetChild(0).gameObject.SetActive(false);
            }
        }
    }
}