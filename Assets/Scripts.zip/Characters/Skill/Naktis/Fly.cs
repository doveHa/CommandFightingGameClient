using UnityEngine;

public class Fly : MonoBehaviour
{
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
    }

    // Update is called once per frame
    void Update()
    {
    }

    //비행
    private static Coroutine NaktisFlight;

    public static void NaktisS1()
    {
        Player player = GameManager.Manager.Player.GetComponent<Player>();

        if (NaktisFlight != null)
        {
            player.GetComponentInChildren<Rigidbody2D>().gravityScale = ConstController.Manager.GravityScale;
            player.StopCoroutine(NaktisFlight);
        }

        NaktisFlight = player.StartCoroutine(NaktisFly(player));
        player.IsJumping = true;

        Debug.Log("NaktisS1");
    }

    private static IEnumerator NaktisFly(Player player)
    {
        ConstController.Manager.GravityScale = player.GetComponentInChildren<Rigidbody2D>().gravityScale;
        player.GetComponentInChildren<Rigidbody2D>().gravityScale = 0;
        player.GetComponentInChildren<Rigidbody2D>().linearVelocityY = 0;
        player.transform.GetChild(0).transform.GetChild(0).position =
            new Vector3(player.transform.GetChild(0).transform.GetChild(0).position.x,
                ConstController.Manager.NaktisFlyYPosition, 0);

        float elapsedTime = 0;
        while (elapsedTime < ConstController.Manager.DurationTime)
        {
            elapsedTime += Time.deltaTime;
            yield return null;
        }

        player.GetComponentInChildren<Rigidbody2D>().gravityScale = ConstController.Manager.GravityScale;
        NaktisFlight = null;
    }
}