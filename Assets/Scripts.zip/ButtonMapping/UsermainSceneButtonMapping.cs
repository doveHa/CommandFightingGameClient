using UnityEngine;
using Handler;
using Manager;

namespace ButtonMapping
{
    public class UsermainSceneButtonMapping : MonoBehaviour
    {
        [SerializeField] private GameObject userMainGroup, characterInfoGroup;
        [SerializeField] private CharacterSelectHandler characterSelectHandler;
        [SerializeField] private CommandRecodeHandler commandRecodeHandler;

        public void mainToCharacterInfo()
        {
            userMainGroup.SetActive(false);
            characterInfoGroup.SetActive(true);
        }

        public async void characterInfoToMain()
        {
            await commandRecodeHandler.SendCommand();
            characterInfoGroup.SetActive(false);
            characterSelectHandler.AllDescriptionOff();
            characterSelectHandler.AllSkillInfoOff();
            userMainGroup.SetActive(true);
        }

        public void Select()
        {
            if (CharacterSelectHandler.CurrentShowCharacter != null)
            {
                CharacterManager.Manager.PlayerCharacterName = CharacterSelectHandler.CurrentShowCharacter;
            }

            characterInfoToMain();
    
            CharacterManager.Manager.CharacterOn();
        }

        public void MatchingStart()
        {
            SteamNetworkManager.Manager.RemoteSteamIdString = Constant.SteamNetworkingType.REMOTESTEAMID;
            SteamNetworkManager.Manager.StartP2P();
        }

        public void Logout()
        {
            Authentication.Authentication.logout(LoginManager.Manager.GetTokens().refreshToken);
        }
    }
}